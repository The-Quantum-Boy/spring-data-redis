package com.sumit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Redisearch1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
